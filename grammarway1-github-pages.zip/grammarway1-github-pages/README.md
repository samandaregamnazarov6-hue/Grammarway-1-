# Grammarway 1 Learner-Friendly Vocabulary Lab

GitHub Pages-ready website. The main file is `index.html`.

## Publish with GitHub Pages
1. Create a new GitHub repository.
2. Upload all files from this folder.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**, choose `main` and `/ (root)`.
5. Save and open the generated `https://...github.io/.../` address.
